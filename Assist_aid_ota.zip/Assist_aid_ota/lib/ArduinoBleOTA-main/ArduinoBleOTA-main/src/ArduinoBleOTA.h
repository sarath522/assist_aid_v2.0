#pragma once

#include "BleOtaDefines.h"
#if defined(NIM_BLE_ARDUINO_LIB)
#include "ArduinoBleOtaNimBle.h"
#else
#include "ArduinoBleOtaCommon.h"
#endif